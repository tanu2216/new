package PageBean;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class RegistrationFormPageFactory {

	WebDriver driver;
	
	@FindBy(id = "usrID")
	@CacheLookup
	WebElement pfuserId;
	
	@FindBy(name = "passid")
	@CacheLookup
	WebElement pfpassword;
	
	@FindBy(id = "usrname")
	@CacheLookup
	WebElement pfname;
	
	@FindBy(id = "addr")
	@CacheLookup
	WebElement pfaddress;
	
	@FindBy(name = "country")
	@CacheLookup
	WebElement pfcountry;
	
	@FindBy(name = "zip")
	@CacheLookup
	WebElement pfzipCode;
	
	@FindBy(name = "email")
	@CacheLookup
	WebElement pfemailId;
	
	@FindBy(name = "sex")
	@CacheLookup
	WebElement pfgender;
	
	@FindBy(name = "en")
	@CacheLookup
	WebElement pflanguage;
	
	@FindBy(name = "submit")
	@CacheLookup
	WebElement pfsubmit;


	public RegistrationFormPageFactory(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public WebElement getUserId() {
		return getUserId();
	}

	public void setUserId(String sfuserId) {
		pfuserId.sendKeys(sfuserId);
	}

	public WebElement getPassword() {
		return getPassword();
	}

	public void setPassword(String sfpassword) {
		pfpassword.sendKeys(sfpassword);
	}

	public WebElement getName() {
		return getName();
	}

	public void setName(String sfname) { 
			pfname.sendKeys(sfname);
	}

	public WebElement getAddress() {
		return getAddress();
	}

	public void setAddress(String sfaddress) {
		pfaddress.sendKeys(sfaddress);
	}

	public WebElement getCountry() {
		return getCountry();
	}

	public void setCountry(String sfcountry) {
		Select dropCountry = new Select(pfcountry);
		dropCountry.selectByVisibleText(sfcountry);
	}

	public WebElement getZipCode() {
		return getZipCode();
	}

	public void setZipCode(String sfzipCode) {
		pfzipCode.sendKeys(sfzipCode);
	}

	public WebElement getEmailId() {
		return getEmailId();
	}

	public void setEmailId(String sfemailId) {
		pfemailId.sendKeys(sfemailId);
	}

	public WebElement getGender() {
		return getGender();
	}

	public void setGender(String gender) {
		pfgender = driver.findElement(By.xpath(gender));
		pfgender.click();
	}

	public WebElement getLanguage() {
		return getLanguage();
	}

	public void setLanguage() {
		pflanguage.click();
	}
	
	public WebElement getSubmit() {
		return getSubmit();
	}
	
	public void setSubmit() {
		pfsubmit.click();
	}

	public void setLanguage(String string) {
		
	
		
	}
	public void RegistrationFormPageFactory(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
}
