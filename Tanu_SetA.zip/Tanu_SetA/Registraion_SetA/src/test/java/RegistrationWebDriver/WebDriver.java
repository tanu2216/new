package RegistrationWebDriver;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class WebDriver {
	static ChromeDriver driver;
	private static Select drpCity;
	public static void main(String[] args) throws InterruptedException {
	Alert alert;

	System.setProperty("webdriver.chrome.driver", "C:\\Users\\TANUSHAR\\Desktop\\Module 3\\Module 3\\chromedriver.exe");
	driver = new ChromeDriver();
	driver.get("C:\\Users\\TANUSHAR\\Desktop\\Module 3\\Module 3\\set A\\WebPages\\RegistrationForm.html");
	Thread.sleep(2000);

	((WebElement) driver.findElement(By.id("submit"))).click();
	Thread.sleep(1000);
	callAlert();

	
	((Alert) driver.findElement(By.id("username"))).sendKeys("Tanu");
	Thread.sleep(1000);
	((WebElement) driver.findElement(By.id("submit"))).click();
	Thread.sleep(1000);
	callAlert();
	
	((Alert) driver.findElement(By.id("password"))).sendKeys("xyz");
	Thread.sleep(1000);
	((WebElement) driver.findElement(By.id("submit"))).click();
	Thread.sleep(1000);
	callAlert();

	((Alert) driver.findElement(By.id("address"))).sendKeys("Talwade");
	Thread.sleep(1000);
	((WebElement) driver.findElement(By.id("submit"))).click();
	Thread.sleep(1000);
	callAlert();
	
	((Alert) driver.findElement(By.id("zipcode"))).sendKeys("123456");
	Thread.sleep(1000);
	((WebElement) driver.findElement(By.id("submit"))).click();
	Thread.sleep(1000);
	callAlert();
	
	((Alert) driver.findElement(By.id("sex"))).sendKeys("Female");
	Thread.sleep(1000);
	((WebElement) driver.findElement(By.id("submit"))).click();
	Thread.sleep(1000);
	callAlert();

	
	((Alert) driver.findElement(By.id("en"))).sendKeys("English");
	Thread.sleep(1000);
	((WebElement) driver.findElement(By.id("submit"))).click();
	Thread.sleep(1000);
	callAlert();

	




	/*********** For Email **************/
	((Alert) driver.findElement(By.id("email"))).sendKeys("tanusharma@gmail.com");
	Thread.sleep(1000);
	driver.findElement(By.id("submit")).click();
	Thread.sleep(1000);
	callAlert();

	
	


	drpCity.selectByVisibleText("India");
	driver.findElement(By.id("submit")).click();
	Thread.sleep(1000);
	callAlert();

	

	
	
	driver.findElement(By.id("submit")).click();
}

private Object findElement(By id) {
		// TODO Auto-generated method stub
		return null;
	}

public static void callAlert() {
	String alertMessage = driver.switchTo().alert().getText();
	System.out.println("Message is : " + alertMessage);
	driver.switchTo().alert().accept();
}
}




