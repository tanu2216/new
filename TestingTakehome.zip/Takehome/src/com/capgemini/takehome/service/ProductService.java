package com.capgemini.takehome.service;

import com.capgemini.takehome.dao.IProductDAO;
import com.capgemini.takehome.dao.ProductDAO;
import com.capgemini.takehome.ui.Product;

public class ProductService implements IProductService {
	IProductDAO daoRef=new ProductDAO();
	
	public ProductService() {
		
	}
	
	public Product getProductDetails(int productCode) {
		
		return daoRef.getProductDetails(productCode);
		
	}

}
    