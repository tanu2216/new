package com.capgemini.takehome.ui;

import java.util.Scanner;

import com.capgemini.takehome.Exception.InvalidProductQuantityException;
import com.capgemini.takehome.Exception.InvalideProductCodeException;
import com.capgemini.takehome.service.IProductService;
import com.capgemini.takehome.service.ProductService;

public class Client {
	public static void main(String args[]) throws InvalideProductCodeException, InvalidProductQuantityException {
		IProductService serref = new ProductService();

		Scanner sc = new Scanner(System.in);
		while (true) {

			System.out.println("1.Generate Bill by Entering Product code and quantity");
			System.out.println("2.Exit");

			int s = Integer.parseInt(sc.next());
			switch (s) {

			case 1:
				System.out.println("Enter Product Code");

				System.out.println("Enter the Product code");
				String code = sc.next();

				System.out.println("Enter the Quantity");
				int qty = Integer.parseInt(sc.next());

				if (code.length() <= 3) {
					System.out.println("It is the Valid code");
					throw new InvalideProductCodeException("Product code is invalid");
					
					}

				if (qty <= 0) {
					System.out.println("it is valid Quantity");
					throw new InvalidProductQuantityException("Quantity is invalid");
					
				}

					int pcode = Integer.parseInt(code);
					Product pref;
					pref = serref.getProductDetails(pcode);
					if (pref == null) {
						System.out.println("Sorry! the product code is not available");
						break;
					}

					System.out.println("Product Name:" + pref.getProduct_name());
					System.out.println("Product Category:" + pref.getProduct_category());
					System.out.println("Product Description:" );
					System.out.println("Product Price:" + pref.getProduct_price());
					System.out.println("Quantity:" +qty);
					System.out.println("lineTotal:"+qty*pref.getProduct_price());
					
			case 2:
				System.exit(0);
				default: System.out.println("ENter correct choice");
				

			}
		}
	}
}