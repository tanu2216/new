package com.capgemini.takehome.dao;

import java.util.HashMap;

import com.capgemini.takehome.ui.Product;
import com.capgemini.takehome.util.CollectionUtil;

public class ProductDAO implements IProductDAO{
	
	public ProductDAO() {
		
	}
	public Product getProductDetails(int productCode) {
		
		
		return CollectionUtil.products.get(productCode);
		
	}

}
