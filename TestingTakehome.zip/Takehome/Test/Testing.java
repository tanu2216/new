import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.takehome.dao.IProductDAO;
import com.capgemini.takehome.dao.ProductDAO;
import com.capgemini.takehome.ui.Product;

public class Testing {
	IProductDAO dao;

	@Before
	public void tearDown() {
	 dao=new ProductDAO();
	}
	
	@Test
	public void test() {
		Product pref;
		boolean flag=true;
		pref=dao.getProductDetails(1001);
		if(pref==null)
			flag=false;
		assertTrue(flag);
		
		pref=dao.getProductDetails(1003);
		if(pref==null)
			flag=false;
		assertTrue(flag);
   
	}
	
	@After
	public void end() {
		dao=null;

}
}
